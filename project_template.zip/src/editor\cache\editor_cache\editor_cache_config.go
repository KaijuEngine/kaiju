package editor_cache

const (
	CacheFolder = "Kaiju"
)
