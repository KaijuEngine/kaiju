package css

import _ "embed"

//go:embed default.css
var DefaultCSS string
