package engine

const (
	DefaultWindowWidth  = 944
	DefaultWindowHeight = 500
)
