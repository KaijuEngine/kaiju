package collision

type Frustum struct {
	Planes [6]Plane
}
